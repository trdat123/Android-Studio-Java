package com.example.chinago;

public class Hotel {
    private int id;
    private String name;
    private String imageURl;
    private String description;
    private int room;

    public Hotel(int id, String name,  String description, int room, String imageURl) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.room = room;
        this.imageURl = imageURl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImageURl() {
        return imageURl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getRoom() {
        return room;
    }

    public void setRoom(int room) {
        this.room = room;
    }

    public void setImageURl(String imageURl) {
        this.imageURl = imageURl;
    }

    @Override
    public String toString() {
        return "Hotel{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", imageURl='" + imageURl + '\'' +
                ", description='" + description + '\'' +
                ", room=" + room +
                '}';
    }
}
