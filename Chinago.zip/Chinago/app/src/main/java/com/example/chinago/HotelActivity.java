package com.example.chinago;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class HotelActivity extends AppCompatActivity {

    private TextView HotelName;
    private TextView HotelDescription;
    private ImageView HotelImage;

    public static final String HOTEL_ID_KEY = "hotelId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel);

        initView();

        Intent intent = getIntent();
        if (null != intent) {
            int hotelId = intent.getIntExtra(HOTEL_ID_KEY, -1);
            if (hotelId != -1) {
                Hotel incomingHotel = Utils.getInstance().getHotelById(hotelId);
                if (null != incomingHotel) {
                    setData(incomingHotel);
                }
            }
        }

        Button showSheet = findViewById(R.id.showSheet);
        showSheet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    private void setData(Hotel hotel) {
        HotelName.setText(hotel.getName());
        HotelDescription.setText(hotel.getDescription());
        Glide.with(this).asBitmap().load(hotel.getImageURl()).into(HotelImage);
    }

    private void initView() {
        HotelName = findViewById(R.id.HotelNameDetail);
        HotelDescription = findViewById(R.id.HotelDescriptionDetail);
        HotelImage = findViewById(R.id.HotelImageDetail);
    }
}