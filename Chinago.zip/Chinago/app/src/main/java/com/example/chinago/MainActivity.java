package com.example.chinago;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView RecView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecView = findViewById(R.id.RecView);

        HotelRecViewAdapter adapter = new HotelRecViewAdapter(this);
        adapter.setHotels(Utils.getInstance().getAllHotels());

        RecView.setAdapter(adapter);
        RecView.setLayoutManager(new GridLayoutManager(this, 2));
    }
}